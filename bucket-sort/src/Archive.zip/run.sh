#!/usr/bin/env bash
./bucket-sort
